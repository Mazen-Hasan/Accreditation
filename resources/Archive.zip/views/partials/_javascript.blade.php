<!-- Scripts -->
<script src="{{ asset('js/app.js') }}"></script>
<script src="{{ URL::asset('js/jquery.validate.js') }}"></script>
<script src="{{ URL::asset('js/parsley.min.js') }}"></script>

<!-- Styles -->
<link href="{{ asset('css/app.css') }}" rel="stylesheet">
<link href="{{ asset('css/custom.css') }}" rel="stylesheet">
<link href="{{ asset('vendors/feather/feather.css') }}" rel="stylesheet">
